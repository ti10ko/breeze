/* This file is auto generated, version 202012132330 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202012132330 SMP Sun Dec 13 23:33:36 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc (Ubuntu 10.2.0-13ubuntu1) 10.2.0, GNU ld (GNU Binutils for Ubuntu) 2.35.1"
